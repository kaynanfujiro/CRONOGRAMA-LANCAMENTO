import type { Modelo } from './types';

/**
 * Modelo de lead time padrão (planilha de fases do setor de Produtos).
 * O servidor cria server/data/modelo.json a partir daqui na primeira execução;
 * depois disso, as mudanças feitas na tela ficam salvas nesse arquivo.
 */
export const MODELO_PADRAO: Modelo = {
  modo: 'seq',
  meta: 240,
  fases: [
    { nome: 'Escopo / Briefing', cor: '#B993EE', dias: 10, bloco: 1, status: ['escopo / briefing'] },
    { nome: 'Sourcing', cor: '#E39A7E', dias: 90, bloco: 2, status: ['sourcing'] },
    { nome: 'Aguardando amostra', cor: '#9A5BB8', dias: 20, bloco: 3, status: ['aguardando amostra'] },
    { nome: 'Teste / Validação', cor: '#D9DB5E', dias: 20, bloco: 4, status: ['teste / validação'] },
    { nome: 'Cadastro SKU / NCM', cor: '#2E6B45', dias: 7, bloco: 5, status: ['cadastro sku / ncm'] },
    { nome: 'Desenvolvimento arte', cor: '#6FA3B5', dias: 10, bloco: 5, status: ['desenvolvimento arte'] },
    { nome: 'First order', cor: '#8A1E91', dias: 60, bloco: 6, status: ['first order'] },
    { nome: 'Em trânsito amostra c/ arte', cor: '#D84B85', dias: 20, bloco: 6, status: ['envio amostra c/ arte', 'em trânsito amostra c/ arte'] },
    { nome: 'Marketing', cor: '#9E837A', dias: 20, bloco: 7, status: ['marketing'] },
    { nome: 'Envio primeiro lote', cor: '#C3102F', dias: 60, bloco: 7, status: ['envio primeiro lote'] },
    { nome: 'Lançamento', cor: '#23906A', dias: 10, bloco: 8, status: ['lançamento'] },
    { nome: 'Chegada primeiro lote', cor: '#50545C', dias: 10, bloco: 8, status: ['chegada primeiro lote'] },
    { nome: 'Ciclo de vida', cor: '#4A86E8', dias: 5, bloco: 9, status: ['ciclo de vida', 'complete', 'concluído'] },
  ],
};

/** Status do ClickUp que não são fases. */
export const STATUS_BACKLOG = ['backlog', 'to do'];
export const STATUS_CANCELADO = ['cancelado', 'cancelled'];

/** Normaliza nomes de status para comparar ("Teste / Validação" → "teste validacao"). */
export const normalizar = (s: string | null | undefined): string =>
  String(s ?? '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();

/** Retorna o índice da fase, -1 para backlog, 'x' para cancelado, ou null se desconhecido. */
export function faseDoStatus(modelo: Modelo, status: string): number | -1 | 'x' | null {
  const k = normalizar(status);
  if (STATUS_BACKLOG.map(normalizar).includes(k)) return -1;
  if (STATUS_CANCELADO.map(normalizar).includes(k)) return 'x';
  const i = modelo.fases.findIndex(
    (f) => normalizar(f.nome) === k || f.status.some((s) => normalizar(s) === k),
  );
  return i >= 0 ? i : null;
}
