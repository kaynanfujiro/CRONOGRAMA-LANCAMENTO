/**
 * Tipos compartilhados entre o servidor (Node) e o web (React).
 * O servidor converte as tarefas do ClickUp neste formato; o web só lê.
 */

/** Situação real de uma fase de um projeto. Datas em ISO (AAAA-MM-DD). */
export interface FaseReal {
  /** Data em que o card entrou nesta fase (vem do histórico de status do ClickUp). */
  ini?: string;
  /** Data em que o card saiu desta fase. */
  fim?: string;
  /** Fase concluída (mesmo sem datas — ex.: histórico anterior ao ClickUp). */
  feito?: boolean;
  /** Fase em andamento agora. */
  emCurso?: boolean;
}

/** Farol decidido no follow-up (campo "Status do Projeto" no ClickUp). */
export interface Farol {
  nome: string; // ex.: "No Prazo", "Atenção", "Atrasado"
  cor: string; // cor da opção no ClickUp
}

export type Situacao = 'Backlog' | 'Andamento' | 'Concluído' | 'Cancelado';

export interface Projeto {
  id: string; // id da tarefa no ClickUp
  nome: string;
  url: string;
  pvl: string | null;
  familia: string | null;
  analistas: string[];
  itens: number | null;
  onda: string | null;
  ano: string | null;
  forecast: number | null;
  statusClickUp: string;
  corStatus: string | null;
  situacao: Situacao;
  /** Farol do follow-up semanal (null = ainda não avaliado). */
  farol: Farol | null;
  /** Próximo passo combinado no follow-up (campo "PRÓXIMO PASSO", opcional). */
  proximoPasso: string | null;
  /** Data de início do card (plano). ISO. */
  inicioPlan: string;
  /** Data de vencimento do card (plano, como está no ClickUp). ISO. */
  vencimentoPlan: string | null;
  dataLancamentoMeta: string | null;
  inicioRealInformado: string | null;
  conclusaoRealInformada: string | null;
  /** Índice da fase → situação real. */
  real: Record<number, FaseReal>;
  atualizadoEm: string | null;
}

export interface FaseModelo {
  nome: string;
  /** Cor da fase (igual à do status no ClickUp). */
  cor: string;
  /** Prazo da fase em dias corridos. */
  dias: number;
  /** Fases com o mesmo bloco podem correr em paralelo. */
  bloco: number;
  /** Nomes de status do ClickUp que representam esta fase. */
  status: string[];
}

export interface Modelo {
  /** 'seq' = fases do mesmo bloco uma após a outra; 'par' = correm juntas. */
  modo: 'seq' | 'par';
  /** Meta de lead time total (dias). */
  meta: number;
  fases: FaseModelo[];
}

export interface RespostaProjetos {
  projetos: Projeto[];
  sincronizadoEm: string;
  origem: 'clickup' | 'cache';
}

export interface StatusLista {
  status: string;
  cor: string;
  tipo: string;
}
