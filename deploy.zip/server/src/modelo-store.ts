/** Guarda o modelo de lead time em server/data/modelo.json. */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import type { Modelo } from '../../shared/types';
import { MODELO_PADRAO } from '../../shared/modelo-padrao';
import { config } from './config';

export function lerModelo(): Modelo {
  try {
    if (existsSync(config.arquivoModelo)) {
      const m = JSON.parse(readFileSync(config.arquivoModelo, 'utf8')) as Modelo;
      if (Array.isArray(m.fases) && m.fases.length) return m;
    }
  } catch (e) {
    console.warn('[modelo] arquivo inválido, usando o padrão:', (e as Error).message);
  }
  return structuredClone(MODELO_PADRAO);
}

export function salvarModelo(m: Modelo): Modelo {
  const limpo: Modelo = {
    modo: m.modo === 'par' ? 'par' : 'seq',
    meta: Math.max(0, Math.round(Number(m.meta) || 0)),
    fases: m.fases.map((f) => ({
      nome: String(f.nome),
      cor: String(f.cor),
      dias: Math.max(0, Math.round(Number(f.dias) || 0)),
      bloco: Math.round(Number(f.bloco) || 0),
      status: Array.isArray(f.status) ? f.status.map(String) : [],
    })),
  };
  mkdirSync(path.dirname(config.arquivoModelo), { recursive: true });
  writeFileSync(config.arquivoModelo, JSON.stringify(limpo, null, 2));
  return limpo;
}
