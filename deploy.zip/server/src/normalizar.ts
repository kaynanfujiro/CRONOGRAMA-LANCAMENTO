/**
 * Converte uma tarefa do ClickUp + histórico de status em um Projeto.
 *
 * Regras:
 * - status do card = fase atual;
 * - cada mudança de status registrada = início real da nova fase e fim real da anterior;
 * - o status em que o card foi criado não tem data real de início
 *   (o projeto já estava nessa fase antes de existir no ClickUp), exceto a 1ª fase;
 * - fases anteriores à primeira registrada contam como concluídas, sem data.
 */
import type { Farol, FaseReal, Modelo, Projeto, Situacao } from '../../shared/types';
import { faseDoStatus, normalizar } from '../../shared/modelo-padrao';
import type { CUCampo, CUTarefa, CUTempoStatus } from './clickup';

/** Nomes dos campos personalizados na lista (maiúsculas/acentos não importam). */
const CAMPOS = {
  pvl: ['CÓDIGO PVL', 'Código Projeto'],
  familia: ['FAMÍLIA'],
  itens: ['QUANTIDADE SUBITENS'],
  onda: ['ONDA - LANÇAMENTO'],
  ano: ['ANO LANÇAMENTO', 'ANO DE LANÇAMENTO'],
  forecast: ['Forecast Inícial', 'Forecast Inicial', 'FORECAST'],
  lancMeta: ['DATA LANÇAMENTO META', 'DATA DE LANÇAMENTO'],
  inicioReal: ['DATA INÍCIO REAL'],
  conclusaoReal: ['DATA CONCLUSÃO REAL'],
  farol: ['Status do Projeto', 'FAROL'],
  proximoPasso: ['PRÓXIMO PASSO', 'PROXIMO PASSO'],
  inicioFaseAtual: ['INÍCIO FASE ATUAL', 'INICIO FASE ATUAL'],
  /** Responsável pelo projeto (em teste: "Solicitante do Teste"); vazio → responsáveis do card. */
  responsavel: ['Solicitante do Teste', 'RESPONSÁVEL'],
};

function campo(t: CUTarefa, nomes: string[]): CUCampo | undefined {
  // primeiro nome exato (distingue "FAMÍLIA" do antigo "Família"), depois normalizado
  for (const n of nomes) {
    const f = t.custom_fields.find((c) => c.name === n);
    if (f) return f;
  }
  for (const n of nomes) {
    const f = t.custom_fields.find((c) => normalizar(c.name) === normalizar(n));
    if (f) return f;
  }
  return undefined;
}

function valorTexto(f?: CUCampo): string | null {
  if (!f || f.value == null || f.value === '') return null;
  if (f.type === 'drop_down') {
    const op = f.type_config?.options?.find((o) => o.orderindex === Number(f.value) || o.id === f.value);
    return op?.name ?? null;
  }
  return String(f.value);
}
function valorOpcao(f?: CUCampo): Farol | null {
  if (!f || f.value == null || f.value === '' || f.type !== 'drop_down') return null;
  const op = f.type_config?.options?.find((o) => o.orderindex === Number(f.value) || o.id === f.value);
  return op ? { nome: op.name, cor: op.color ?? '#999999' } : null;
}
function valorNumero(f?: CUCampo): number | null {
  if (!f || f.value == null || f.value === '') return null;
  const n = Number(f.value);
  return Number.isFinite(n) ? n : null;
}
function valorData(f?: CUCampo): string | null {
  const n = valorNumero(f);
  return n == null ? null : diaISO(n);
}

/** Responsável do campo personalizado; se vazio, os responsáveis (assignees) do card. */
function responsaveis(t: CUTarefa): string[] {
  const doCampo = valorTexto(campo(t, CAMPOS.responsavel));
  if (doCampo) return [doCampo];
  return t.assignees.map((a) => a.username || a.email || '').filter(Boolean);
}

/** Converte milissegundos em data ISO do dia (fuso de Brasília). */
export function diaISO(ms: number | string | null | undefined): string | null {
  if (ms == null || ms === '') return null;
  const d = new Date(Number(ms));
  if (Number.isNaN(d.getTime())) return null;
  return d.toLocaleDateString('sv-SE', { timeZone: 'America/Sao_Paulo' }); // AAAA-MM-DD
}

export function paraProjeto(t: CUTarefa, tempo: CUTempoStatus | undefined, modelo: Modelo): Projeto {
  const ultima = modelo.fases.length - 1;
  const criado = diaISO(t.date_created);

  // histórico em ordem cronológica
  const hist = (tempo?.status_history ?? [])
    .map((h) => ({ fase: faseDoStatus(modelo, h.status), desde: diaISO(h.total_time?.since) }))
    .filter((h): h is { fase: ReturnType<typeof faseDoStatus>; desde: string } => h.desde != null)
    .sort((a, b) => a.desde.localeCompare(b.desde));
  if (!hist.length) hist.push({ fase: faseDoStatus(modelo, t.status.status), desde: criado ?? '' });

  const real: Record<number, FaseReal> = {};
  let situacao: Situacao = 'Andamento';
  let maiorFase = -1;

  hist.forEach((h, j) => {
    if (h.fase === 'x') {
      situacao = 'Cancelado';
      return;
    }
    if (h.fase == null || h.fase < 0) return;
    const prox = hist.slice(j + 1).find((n) => typeof n.fase === 'number' && n.fase >= 0);
    const semInicio = j === 0 && h.desde === criado && h.fase > 0;
    const r: FaseReal = {};
    if (!semInicio) r.ini = h.desde;
    if (prox) {
      r.fim = prox.desde;
      r.feito = true;
    } else r.emCurso = true;
    real[h.fase] = { ...(real[h.fase] ?? {}), ...r };
    maiorFase = Math.max(maiorFase, h.fase);
  });

  for (let i = 0; i < maiorFase; i++) if (!real[i]) real[i] = { feito: true };
  for (const r of Object.values(real)) if (r.feito) delete r.emCurso;

  // a fase atual é sempre a do status de agora
  const atual = faseDoStatus(modelo, t.status.status);
  if (atual === 'x') situacao = 'Cancelado';
  else if (atual === -1 && maiorFase < 0) situacao = 'Backlog';
  else if (typeof atual === 'number' && atual >= 0 && real[atual]) {
    delete real[atual].fim;
    delete real[atual].feito;
    real[atual].emCurso = true;
  }
  // "INÍCIO FASE ATUAL" preenchido à mão vale mais que o histórico (projeto já estava na fase antes do ClickUp)
  const inicioManual = valorData(campo(t, CAMPOS.inicioFaseAtual));
  if (inicioManual && typeof atual === 'number' && atual >= 0 && real[atual]) real[atual].ini = inicioManual;

  if (real[ultima] && situacao !== 'Cancelado') {
    situacao = 'Concluído';
    real[ultima].emCurso = false;
  }

  return {
    id: t.id,
    nome: t.name,
    url: t.url,
    pvl: valorTexto(campo(t, CAMPOS.pvl)),
    familia: valorTexto(campo(t, CAMPOS.familia)),
    analistas: responsaveis(t),
    itens: valorNumero(campo(t, CAMPOS.itens)),
    onda: valorTexto(campo(t, CAMPOS.onda)),
    ano: valorTexto(campo(t, CAMPOS.ano)),
    forecast: valorNumero(campo(t, CAMPOS.forecast)),
    statusClickUp: t.status.status,
    corStatus: t.status.color ?? null,
    situacao,
    farol: valorOpcao(campo(t, CAMPOS.farol)),
    proximoPasso: valorTexto(campo(t, CAMPOS.proximoPasso)),
    inicioPlan: diaISO(t.start_date) ?? criado ?? new Date().toISOString().slice(0, 10),
    vencimentoPlan: diaISO(t.due_date),
    dataLancamentoMeta: valorData(campo(t, CAMPOS.lancMeta)),
    inicioRealInformado: valorData(campo(t, CAMPOS.inicioReal)),
    conclusaoRealInformada: valorData(campo(t, CAMPOS.conclusaoReal)),
    real,
    atualizadoEm: diaISO(t.date_updated),
  };
}
