/**
 * API do cronograma. O navegador nunca vê o token do ClickUp: ele fica só aqui.
 *
 * GET  /api/projetos            projetos da lista (cache de CACHE_SECONDS; ?atualizar=1 força leitura)
 * GET  /api/status              status configurados na lista do ClickUp
 * GET  /api/modelo              modelo de lead time
 * PUT  /api/modelo              salva o modelo de lead time
 * PATCH /api/projetos/:id/status  muda a fase (status) do card no ClickUp
 */
import express, { type NextFunction, type Request, type Response } from 'express';
import { existsSync } from 'node:fs';
import path from 'node:path';
import type { RespostaProjetos, StatusLista } from '../../shared/types';
import { arquivoEnv, config, validarConfig } from './config';
import { ErroClickUp, listarTarefas, mudarStatus, statusDaLista, tempoEmStatus } from './clickup';
import { paraProjeto } from './normalizar';
import { lerModelo, salvarModelo } from './modelo-store';
import { TAREFAS_DEMO, TEMPO_DEMO } from './demo';

const app = express();
app.use(express.json({ limit: '200kb' }));

let cache: { em: number; dados: RespostaProjetos } | null = null;

async function buscarProjetos(forcar: boolean): Promise<RespostaProjetos> {
  if (!forcar && cache && Date.now() - cache.em < config.cacheSegundos * 1000) {
    return { ...cache.dados, origem: 'cache' };
  }
  const modelo = lerModelo();
  const tarefas = config.demo ? TAREFAS_DEMO : await listarTarefas(config.listId);
  let tempos: Awaited<ReturnType<typeof tempoEmStatus>> = {};
  if (config.demo) tempos = TEMPO_DEMO;
  else if (tarefas.length) {
    try {
      tempos = await tempoEmStatus(tarefas.map((t) => t.id));
    } catch (e) {
      // sem histórico o cronograma ainda funciona (só não mostra datas reais)
      console.warn('[clickup] não foi possível ler o tempo em status:', (e as Error).message);
      console.warn('          Confira se o ClickApp "Total time in Status" está ativo no espaço.');
    }
  }
  console.log(`[clickup] ${tarefas.length} projetos lidos da lista ${config.listId}`);
  const dados: RespostaProjetos = {
    projetos: tarefas.map((t) => paraProjeto(t, tempos[t.id], modelo)),
    sincronizadoEm: new Date().toISOString(),
    origem: 'clickup',
  };
  cache = { em: Date.now(), dados };
  return dados;
}

// helper para rotas async
const rota =
  (fn: (req: Request, res: Response) => Promise<unknown>) => (req: Request, res: Response, next: NextFunction) =>
    fn(req, res).catch(next);

/** Diagnóstico: abra http://localhost:3001/api/saude no navegador. */
app.get(
  '/api/saude',
  rota(async (_req, res) => {
    const erros = validarConfig();
    let teste = 'não testado';
    if (!erros.length && !config.demo) {
      try {
        const lidas = await listarTarefas(config.listId);
        teste = `ok — ${lidas.length} tarefas encontradas na lista`;
      } catch (e) {
        teste = 'falhou: ' + (e as Error).message;
        erros.push(teste);
      }
    }
    res.json({
      ok: erros.length === 0,
      erros,
      demo: config.demo,
      arquivoEnv: arquivoEnv ?? 'NÃO ENCONTRADO',
      token: config.token ? config.token.slice(0, 6) + '…' + config.token.slice(-4) : '(vazio)',
      lista: config.listId,
      testeClickUp: teste,
    });
  }),
);

app.get(
  '/api/projetos',
  rota(async (req, res) => {
    res.json(await buscarProjetos(req.query.atualizar === '1'));
  }),
);

app.get(
  '/api/status',
  rota(async (_req, res) => {
    if (config.demo) {
      res.json(lerModelo().fases.map((f) => ({ status: f.status[0], cor: f.cor, tipo: 'custom' })));
      return;
    }
    const lista: StatusLista[] = (await statusDaLista(config.listId)).map((s) => ({
      status: s.status,
      cor: s.color,
      tipo: s.type,
    }));
    res.json(lista);
  }),
);

app.get('/api/modelo', (_req, res) => {
  res.json(lerModelo());
});

app.put('/api/modelo', (req, res) => {
  const m = req.body;
  if (!m || !Array.isArray(m.fases) || !m.fases.length) {
    res.status(400).json({ erro: 'Modelo inválido: envie { modo, meta, fases: [...] }.' });
    return;
  }
  const salvo = salvarModelo(m);
  cache = null; // o mapeamento de status pode ter mudado
  res.json(salvo);
});

app.patch(
  '/api/projetos/:id/status',
  rota(async (req, res) => {
    const status = String(req.body?.status ?? '').trim();
    if (!status) {
      res.status(400).json({ erro: 'Informe o novo status.' });
      return;
    }
    if (config.demo) {
      res.status(400).json({ erro: 'No modo demonstração não é possível mudar o ClickUp.' });
      return;
    }
    await mudarStatus(req.params.id, status);
    cache = null;
    res.json({ ok: true });
  }),
);

// Em produção, o mesmo servidor entrega o site (web/dist)
if (existsSync(config.pastaWeb)) {
  app.use(express.static(config.pastaWeb));
  app.get(/^\/(?!api\/).*/, (_req, res) => res.sendFile(path.join(config.pastaWeb, 'index.html')));
}

// erros
app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  const status = err instanceof ErroClickUp ? (err.status === 401 ? 401 : 502) : 500;
  const msg = err instanceof Error ? err.message : 'Erro inesperado.';
  console.error('[api]', msg);
  res.status(status).json({ erro: msg });
});

const erros = validarConfig();
if (erros.length) {
  console.warn('\n⚠️  Configuração incompleta:\n - ' + erros.join('\n - ') + '\n   Copie .env.example para .env e preencha.\n');
}

app.listen(config.porta, () => {
  console.log(`API do cronograma em http://localhost:${config.porta}${config.demo ? '  (modo DEMO)' : ''}`);
  console.log(`  .env: ${arquivoEnv ?? 'NÃO ENCONTRADO (crie o arquivo .env ao lado do package.json)'}`);
  console.log(`  diagnóstico: http://localhost:${config.porta}/api/saude`);
});
