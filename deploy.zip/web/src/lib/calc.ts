/**
 * O coração do cronograma: planejado × real × projeção de cada projeto.
 *
 * - Planejado: data de início do card + prazos do modelo (por bloco).
 * - Real: datas das mudanças de status no ClickUp.
 * - Projeção: a fase atual termina no fim previsto ou hoje (o que for mais tarde);
 *   as fases seguintes vêm em sequência com os prazos do modelo.
 * - Desvio: conclusão projetada − conclusão planejada (dias).
 */
import type { Modelo, Projeto } from '@shared/types';
import { DIA, deISO, dias } from './datas';

export type Estado = 'feito' | 'atual' | 'futuro';
export type Saude = 'ok' | 'warn' | 'bad' | 'neutral';

export interface FaseCalc {
  i: number;
  nome: string;
  cor: string;
  prazo: number;
  /** posição na raia quando há fases paralelas */
  slot: number;
  nslot: number;
  /** planejado */
  ps: number;
  pe: number;
  /** real (null = sem data registrada) */
  rs: number | null;
  re: number | null;
  /** fim previsto da fase em curso */
  fimPrevisto: number | null;
  /** projeção das fases futuras */
  xs: number | null;
  xe: number | null;
  estado: Estado;
}

export interface ProjetoCalc {
  p: Projeto;
  fases: FaseCalc[];
  inicioPlan: number;
  fimPlan: number;
  concluido: boolean;
  cancelado: boolean;
  semInfo: boolean;
  fimProj: number | null;
  desvio: number | null;
  lancPlan: number;
  lancProj: number | null;
  saude: Saude;
  saudeTxt: string;
  atuais: number[];
  esperadas: number[];
}

/** Fases agrupadas por bloco, na ordem do modelo. */
export function blocos(m: Modelo): number[][] {
  const mapa = new Map<number, number[]>();
  m.fases.forEach((f, i) => {
    if (!mapa.has(f.bloco)) mapa.set(f.bloco, []);
    mapa.get(f.bloco)!.push(i);
  });
  return [...mapa.values()];
}

export function leadTime(m: Modelo, modo: Modelo['modo'] = m.modo): number {
  return blocos(m).reduce(
    (s, ix) =>
      s + (modo === 'par' ? Math.max(...ix.map((i) => m.fases[i].dias)) : ix.reduce((a, i) => a + m.fases[i].dias, 0)),
    0,
  );
}

export function calcular(p: Projeto, m: Modelo, hoje: number): ProjetoCalc {
  const par = m.modo === 'par';
  const dur = m.fases.map((f) => f.dias);
  const ultima = m.fases.length - 1;
  const iLanc = Math.max(0, m.fases.findIndex((f) => f.nome.toLowerCase().startsWith('lançamento')));
  const cancelado = p.situacao === 'Cancelado';
  const R = p.real ?? {};
  const semInfo = Object.keys(R).length === 0;

  const fases: FaseCalc[] = m.fases.map((f, i) => ({
    i, nome: f.nome, cor: f.cor, prazo: f.dias, slot: 0, nslot: 1,
    ps: 0, pe: 0, rs: null, re: null, fimPrevisto: null, xs: null, xe: null, estado: 'futuro',
  }));

  // ---------- planejado ----------
  let t = deISO(p.inicioPlan);
  for (const ix of blocos(m)) {
    if (par) {
      ix.forEach((i, k) => Object.assign(fases[i], { ps: t, pe: t + dur[i] * DIA, slot: k, nslot: ix.length }));
      t += Math.max(...ix.map((i) => dur[i])) * DIA;
    } else {
      for (const i of ix) {
        fases[i].ps = t;
        t += dur[i] * DIA;
        fases[i].pe = t;
      }
    }
  }
  const fimPlan = t;

  // ---------- real + projeção ----------
  let a = R[0]?.ini ? deISO(R[0].ini) : deISO(p.inicioPlan);
  for (const ix of blocos(m)) {
    let fimBloco = a;
    let ancora = a;
    for (const i of ix) {
      const f = fases[i];
      const r = R[i] ?? {};
      const inicioPossivel = par ? a : ancora;
      let e: number;
      if (r.fim || r.feito) {
        f.estado = 'feito';
        f.rs = r.ini ? deISO(r.ini) : null;
        f.re = r.fim ? deISO(r.fim) : null;
        e = f.re ?? f.pe;
      } else if (r.ini || r.emCurso) {
        f.estado = 'atual';
        f.rs = r.ini ? deISO(r.ini) : null;
        const base = f.rs != null ? f.rs + dur[i] * DIA : f.pe; // sem início registrado: usa o fim planejado
        f.fimPrevisto = cancelado ? base : Math.max(base, hoje);
        e = f.fimPrevisto;
      } else {
        f.estado = 'futuro';
        if (!cancelado && !semInfo) {
          f.xs = Math.max(inicioPossivel, hoje);
          f.xe = f.xs + dur[i] * DIA;
          e = f.xe;
        } else e = f.pe;
      }
      ancora = e;
      fimBloco = Math.max(fimBloco, e);
    }
    a = fimBloco;
  }

  const concluido = p.situacao === 'Concluído';
  const fimProj = cancelado || semInfo ? null : concluido ? (fases[ultima].re ?? fases[ultima].rs ?? a) : a;
  const desvio = fimProj == null ? null : dias(fimPlan, fimProj);

  let atuais = fases.filter((f) => f.estado === 'atual').map((f) => f.i);
  if (!atuais.length && !concluido && !semInfo) {
    const prox = fases.find((f) => f.estado === 'futuro');
    if (prox) atuais = [prox.i];
  }
  if (concluido) atuais = [ultima];
  const esperadas = fases.filter((f) => f.ps <= hoje && f.pe > hoje).map((f) => f.i);

  let saude: Saude;
  let saudeTxt: string;
  if (cancelado) [saude, saudeTxt] = ['neutral', 'Cancelado'];
  else if (semInfo) [saude, saudeTxt] = ['neutral', 'Backlog'];
  else if (concluido) [saude, saudeTxt] = [desvio! > 0 ? 'warn' : 'ok', 'Lançado' + (desvio! > 0 ? ` +${desvio} d` : '')];
  else if (desvio! <= 0) [saude, saudeTxt] = ['ok', desvio! < 0 ? `${desvio} d (adiantado)` : 'No prazo'];
  else if (desvio! <= 15) [saude, saudeTxt] = ['warn', `+${desvio} d`];
  else [saude, saudeTxt] = ['bad', `+${desvio} d`];

  return {
    p, fases, inicioPlan: deISO(p.inicioPlan), fimPlan, concluido, cancelado, semInfo, fimProj, desvio,
    lancPlan: fases[iLanc].ps, lancProj: fases[iLanc].rs ?? fases[iLanc].xs ?? null,
    saude, saudeTxt, atuais, esperadas,
  };
}

/** Cor da pílula de desvio de uma fase. */
export const saudeDesvio = (d: number): Saude => (d <= 0 ? 'ok' : d <= 7 ? 'warn' : 'bad');
