import type { Modelo, RespostaProjetos, StatusLista } from '@shared/types';

async function req<T>(url: string, init?: RequestInit): Promise<T> {
  const r = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...init });
  const corpo = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((corpo as { erro?: string }).erro ?? `Erro ${r.status}`);
  return corpo as T;
}

export interface Saude { ok: boolean; erros: string[]; demo: boolean; arquivoEnv: string; testeClickUp: string }

export const api = {
  saude: () => req<Saude>('/api/saude'),
  projetos: (atualizar = false) => req<RespostaProjetos>(`/api/projetos${atualizar ? '?atualizar=1' : ''}`),
  status: () => req<StatusLista[]>('/api/status'),
  modelo: () => req<Modelo>('/api/modelo'),
  salvarModelo: (m: Modelo) => req<Modelo>('/api/modelo', { method: 'PUT', body: JSON.stringify(m) }),
  mudarStatus: (id: string, status: string) =>
    req<{ ok: true }>(`/api/projetos/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
};
