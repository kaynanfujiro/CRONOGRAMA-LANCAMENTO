import type { Modelo } from '@shared/types';
import { blocos, leadTime } from '../lib/calc';
import { Pill, Rotulo } from './ui';

/** Onde se define o prazo (timing) de cada status/fase. */
export function ModeloPanel({ modelo, alterar, salvando, erro }: { modelo: Modelo; alterar: (m: Modelo) => void; salvando: boolean; erro: string | null }) {
  const par = modelo.modo === 'par';
  const total = leadTime(modelo);
  const setDias = (i: number, v: number) =>
    alterar({ ...modelo, fases: modelo.fases.map((f, j) => (j === i ? { ...f, dias: Math.max(0, v || 0) } : f)) });

  return (
    <details open className="rounded-lg border border-line bg-surface px-4 py-3">
      <summary className="flex cursor-pointer flex-wrap justify-between gap-2.5 font-display text-[17px] uppercase tracking-wide">
        Modelo de lead time por fase
        <span className="flex items-center gap-2 font-sans text-[13px] normal-case tracking-normal text-muted">
          Lead time <b className="text-ink">{total} dias</b> · meta {modelo.meta} d
          <Pill saude={total > modelo.meta ? 'bad' : 'ok'}>{total > modelo.meta ? `+${total - modelo.meta} d` : 'dentro da meta'}</Pill>
          {salvando && <span>salvando…</span>}
        </span>
      </summary>

      <div className="mt-3 flex flex-wrap items-center gap-x-3.5 gap-y-2">
        <Rotulo>Fases paralelas</Rotulo>
        <span className="inline-flex overflow-hidden rounded-md border border-line" role="group">
          {(['par', 'seq'] as const).map((m) => (
            <button
              key={m}
              type="button"
              aria-pressed={modelo.modo === m}
              onClick={() => alterar({ ...modelo, modo: m })}
              className={`px-2.5 py-1.5 text-[13px] ${modelo.modo === m ? 'bg-ink text-bg' : ''}`}
            >
              {m === 'par' ? 'Correm juntas' : 'Uma após a outra'} <small className="font-mono opacity-75">{leadTime(modelo, m)} d</small>
            </button>
          ))}
        </span>
        <label className="flex items-center gap-2 text-[13px] text-muted">
          Meta
          <input
            type="number"
            className="w-16 rounded border border-line bg-bg px-1.5 py-0.5 text-right font-mono text-xs"
            value={modelo.meta}
            onChange={(e) => alterar({ ...modelo, meta: Math.max(0, +e.target.value || 0) })}
          />
          dias
        </label>
      </div>

      {/* barra proporcional do lead time */}
      <div className="my-3 flex h-3.5 gap-0.5 overflow-hidden rounded">
        {blocos(modelo).map((ix) => {
          const len = par ? Math.max(...ix.map((i) => modelo.fases[i].dias)) : ix.reduce((a, i) => a + modelo.fases[i].dias, 0);
          return (
            <div key={ix.join()} className={`flex min-w-[3px] ${par && ix.length > 1 ? 'flex-col gap-px' : ''}`} style={{ flex: len }}>
              {ix.map((i) => (
                <div
                  key={i}
                  title={`${modelo.fases[i].nome}: ${modelo.fases[i].dias} d`}
                  style={par && ix.length > 1 ? { background: modelo.fases[i].cor, flex: 1, width: `${(modelo.fases[i].dias / Math.max(len, 1)) * 100}%` } : { background: modelo.fases[i].cor, flex: modelo.fases[i].dias }}
                />
              ))}
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-[repeat(auto-fill,minmax(220px,1fr))] items-start gap-2">
        {blocos(modelo).map((ix) => (
          <div key={ix.join()} className={`relative flex flex-col gap-1.5 ${ix.length > 1 ? 'rounded-lg border-[1.5px] border-dashed border-muted px-1.5 pb-1.5 pt-[18px]' : ''}`}>
            {ix.length > 1 && <span className="absolute left-2 top-[3px] font-mono text-[10px] font-semibold uppercase text-muted">∥ paralelas</span>}
            {ix.map((i) => {
              const f = modelo.fases[i];
              return (
                <label key={f.nome} className="flex items-center gap-2 rounded-md border border-line px-2 py-1.5 text-[12.5px]">
                  <i className="h-2.5 w-2.5 flex-none rounded-sm" style={{ background: f.cor }} />
                  <span className="min-w-0 flex-1">{f.nome}</span>
                  <input
                    type="number"
                    min={0}
                    max={400}
                    value={f.dias}
                    onChange={(e) => setDias(i, +e.target.value)}
                    className="w-14 rounded border border-line bg-bg px-1.5 py-0.5 text-right font-mono text-xs"
                  />
                  <em className="text-[11px] not-italic text-muted">d</em>
                </label>
              );
            })}
          </div>
        ))}
      </div>
      <p className="mt-3 max-w-[75ch] text-[12.5px] text-muted">
        O planejado de cada projeto é a Data de início do card no ClickUp + estes prazos. Mude um número e o cronograma inteiro se recalcula (salvo no servidor, vale para todos).
      </p>
      {erro && <p className="mt-1 text-[12.5px] text-bad">Não foi possível salvar: {erro}</p>}
    </details>
  );
}
